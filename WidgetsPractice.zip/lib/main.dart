import 'package:flutter/material.dart';
import 'package:widgetspractice/greeting.dart';
import 'package:widgetspractice/counter.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Widgets Practice',
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Widgets Practice'),
        ),
        backgroundColor: Colors.yellow,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              GreetingWidget(message: 'Namasteee!'),
              GreetingWidget(message: 'Guten Mooorgen!'),
              GreetingWidget(message: 'Saluuut!'),
              CounterWidget(),
            ],
          ),
        ),
      ),
    );
  }
}
