package com.example.widgetspractice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
